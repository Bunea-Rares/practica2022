<?php if(Session::has('message')): ?>
    <div>
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<form action="<?php echo e(route('forget.password.post')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div>
        <label for="email_address">E-Mail Address</label>
        <div>
            <input type="text" id="email_address" name="email" required autofocus>
            <?php if($errors->has('email')): ?>
                <span><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div>
        <button type="submit">
            Send Password Reset Link
        </button>
    </div>
</form>
<?php /**PATH /var/www/resources/views/forgot-password.blade.php ENDPATH**/ ?>