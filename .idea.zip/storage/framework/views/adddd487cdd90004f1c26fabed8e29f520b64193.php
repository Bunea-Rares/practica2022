<h1>Forget Password Email</h1>
You can reset password from bellow link:
<a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a>
<?php /**PATH /var/www/resources/views/mail-forgot-password.blade.php ENDPATH**/ ?>