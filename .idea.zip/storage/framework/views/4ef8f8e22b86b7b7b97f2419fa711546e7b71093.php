<form action="<?php echo e(route('reset.password.post')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="token" value="<?php echo e($token); ?>">
    <div>
        <label for="email_address">E-Mail Address</label>
            <input type="text" id="email_address" name="email" required autofocus>
            <?php if($errors->has('email')): ?>
                <span><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
    </div>
    <div>
        <label for="password">Password</label>
        <div>
            <input type="password" id="password" name="password" required autofocus>
            <?php if($errors->has('password')): ?>
                <span><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div>
        <label for="password-confirm">Confirm Password</label>
        <div>
            <input type="password" id="password-confirm" name="password_confirmation" required autofocus>
            <?php if($errors->has('password_confirmation')): ?>
                <span><?php echo e($errors->first('password_confirmation')); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div>
        <button type="submit">
            Reset Password
        </button>
    </div>
</form>
<?php /**PATH /var/www/resources/views/reset-password.blade.php ENDPATH**/ ?>